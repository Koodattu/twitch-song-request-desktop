﻿using System.Windows.Controls;

namespace TwitchSongRequest.View
{
    /// <summary>
    /// Interaction logic for ConnectionStatusUserControl.xaml
    /// </summary>
    public partial class ConnectionStatusUserControl : UserControl
    {
        public ConnectionStatusUserControl()
        {
            InitializeComponent();
        }
    }
}
