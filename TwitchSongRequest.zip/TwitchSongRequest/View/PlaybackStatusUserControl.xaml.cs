﻿using System.Windows.Controls;

namespace TwitchSongRequest.View
{
    /// <summary>
    /// Interaction logic for PlaybackStatusUserControl.xaml
    /// </summary>
    public partial class PlaybackStatusUserControl : UserControl
    {
        public PlaybackStatusUserControl()
        {
            InitializeComponent();
        }
    }
}
