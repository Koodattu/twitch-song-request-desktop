﻿using System.Windows.Controls;

namespace TwitchSongRequest.View
{
    /// <summary>
    /// Interaction logic for SetupUserControl.xaml
    /// </summary>
    public partial class SetupUserControl : UserControl
    {
        public SetupUserControl()
        {
            InitializeComponent();
        }
    }
}
