﻿using System.Windows.Controls;

namespace TwitchSongRequest.View
{
    /// <summary>
    /// Interaction logic for PlaybackControlsUserControl.xaml
    /// </summary>
    public partial class PlaybackControlsUserControl : UserControl
    {
        public PlaybackControlsUserControl()
        {
            InitializeComponent();
        }
    }
}
