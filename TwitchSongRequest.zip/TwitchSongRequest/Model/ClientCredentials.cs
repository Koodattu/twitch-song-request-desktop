﻿namespace TwitchSongRequest.Model
{
    internal class ClientCredentials
    {
        public string? ClientId { get; set; }
        public string? ClientSecret { get; set; }
    }
}
