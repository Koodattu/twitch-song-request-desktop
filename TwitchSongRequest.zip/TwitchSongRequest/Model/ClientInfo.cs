﻿namespace TwitchSongRequest.Model
{
    internal class ClientInfo
    {
        public string? AccountName { get; set; }
        public WebBrowser Browser { get; set; }
        public string? Scope { get; set; }
    }
}
