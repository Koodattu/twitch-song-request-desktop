﻿namespace TwitchSongRequest.Services.Api
{
    internal interface IYoutubeSongService : ISongService
    {
    }
}
