﻿using System;
namespace TwitchSongRequest.Services.Api
{
    internal interface ISpotifySongService : ISongService
    {
    }
}
